function init(hero) {
    hero.setName("Old Guard");
    hero.setTier(6);

    hero.setHelmet("item.superhero_armor.piece.hood");
    hero.setChestplate("item.superhero_armor.piece.chestpiece");
    hero.setLeggings("item.superhero_armor.piece.pants");
    hero.setBoots("item.superhero_armor.piece.boots");

    hero.addPowers("cosmicverse:old_guard_powers");

    hero.addAttribute("FALL_RESISTANCE",   0.6, 1);
    hero.addAttribute("BASE_SPEED_LEVELS", 1.0, 0);
    hero.addAttribute("JUMP_HEIGHT",       0.5, 0);

    hero.addKeyBind("SHIELD",         "key.forcefield", 1);
    hero.addKeyBind("GROUND_SMASH",   "Ground Smash",   2);
    hero.addKeyBind("CHARGED_PUNCH",  "Power Punch",    3);
    hero.addKeyBind("TELEPORT",       "Go to the Moon", 4);

    hero.setHasProperty((entity, property) => property == "BREATHE_SPACE");

    hero.addAttributeProfile("NORMAL", profile => {
        profile.inheritDefaults();
        profile.addAttribute("PUNCH_DAMAGE", 8.0, 0);
    });
    hero.addAttributeProfile("POWERED", profile => {
        profile.inheritDefaults();
        profile.addAttribute("PUNCH_DAMAGE", 30.0, 0);
    });

    hero.setAttributeProfile(getAttributeProfile);
}

function getAttributeProfile(entity) {
    return entity.getData("fiskheroes:punchmode") ? "POWERED" : "NORMAL";
}
