function init(hero) {
    hero.setName("Cosmic Punch");
    hero.setTier(10);

    hero.setHelmet("item.superhero_armor.piece.hood");
    hero.setChestplate("item.superhero_armor.piece.chestpiece");
    hero.setLeggings("item.superhero_armor.piece.pants");
    hero.setBoots("item.superhero_armor.piece.boots");

    hero.addPowers("cosmicverse:cosmic_punch_powers");

    hero.addAttribute("PUNCH_DAMAGE",      16.0, 0);
    hero.addAttribute("SPRINT_SPEED",      0.4, 1);
    hero.addAttribute("BASE_SPEED_LEVELS", 3.0, 0);
    hero.addAttribute("JUMP_HEIGHT",       1.5, 0);
    hero.addAttribute("FALL_RESISTANCE",   1.0, 1);

    hero.addKeyBind("CHARGED_BEAM", "Cosmic Punch",   1);
    hero.addKeyBind("SUPER_SPEED",  "key.superSpeed", 2);
    hero.addKeyBind("SHIELD",       "key.forcefield", 3);
    hero.addKeyBind("INVISIBILITY", "key.invisibility", 4);
    hero.addKeyBind("TELEPORT",     "Go to the Moon", 5);

    hero.setHasProperty((entity, property) => property == "BREATHE_SPACE");

    hero.setTickHandler(onTick);
}

function onTick(entity, manager) {
    var dodge = entity.getData("cosmicverse:dyn/dodge_active");
    if (dodge) {
        var timer = entity.getData("cosmicverse:dyn/dodge_timer") + 1;
        manager.setData(entity, "cosmicverse:dyn/dodge_timer", timer);
        if (timer >= 100) {
            manager.setData(entity, "cosmicverse:dyn/dodge_active", false);
            manager.setData(entity, "cosmicverse:dyn/dodge_timer", 0);
        }
    }
}
