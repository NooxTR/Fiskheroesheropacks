function init(hero) {
    hero.setName("Cosmic Spider-Man");
    hero.setTier(10);

    hero.setHelmet("item.superhero_armor.piece.mask");
    hero.setChestplate("item.superhero_armor.piece.chestpiece");
    hero.setLeggings("item.superhero_armor.piece.pants");
    hero.setBoots("item.superhero_armor.piece.boots");

    hero.addPowers("cosmicverse:cosmic_powers");

    hero.addAttribute("FALL_RESISTANCE", 1.0, 1);
    hero.addAttribute("PUNCH_DAMAGE", 5.0, 0);

    hero.addKeyBind("CHARGED_BEAM",    "Power Suppression Beam", 1);
    hero.addKeyBind("INTANGIBILITY",   "key.intangibility",      2);
    hero.addKeyBind("SPELL_MENU",      "key.spellMenu",          3);
    hero.addKeyBind("TELEKINESIS",     "key.telekinesis",        4);
    hero.addKeyBind("TENTACLES",       "key.tentacles",          5);

    hero.addKeyBind("TENTACLE_JAB",    "key.tentacleJab",        1);
    hero.addKeyBind("TENTACLE_GRAB",   "key.tentacleGrab",       2);
    hero.addKeyBind("TENTACLE_STRIKE", "key.tentacleStrike",     3);

    hero.addKeyBind("TELEPORT",        "key.teleport",           1);
    hero.addKeyBind("SHIELD",          "key.forcefield",         2);

    hero.setKeyBindEnabled(isKeyBindEnabled);
    hero.setModifierEnabled(isModifierEnabled);
}

function armsActive(entity) {
    return entity.getData("fiskheroes:tentacles") != null;
}

function isKeyBindEnabled(entity, keyBind) {
    var sneaking = entity.isSneaking();
    var arms = armsActive(entity);

    if (sneaking && !arms) {
        return keyBind == "TELEPORT" || keyBind == "SHIELD";
    }

    if (arms) {
        switch (keyBind) {
        case "TENTACLES":
        case "TENTACLE_JAB":
        case "TENTACLE_GRAB":
        case "TENTACLE_STRIKE":
            return true;
        default:
            return false;
        }
    }

    switch (keyBind) {
    case "CHARGED_BEAM":
        return entity.getHeldItem().isEmpty() && !entity.getData("fiskheroes:shield_blocking");
    case "INTANGIBILITY":
        return entity.getHeldItem().isEmpty();
    case "SPELL_MENU":
        return entity.getData("fiskheroes:beam_charge") == 0 && !entity.getData("fiskheroes:shield_blocking");
    case "TELEKINESIS":
        return entity.getData("fiskheroes:beam_charge") == 0 && !entity.getData("fiskheroes:shield_blocking");
    case "TENTACLES":
        return true;
    case "TENTACLE_JAB":
    case "TENTACLE_GRAB":
    case "TENTACLE_STRIKE":
    case "TELEPORT":
    case "SHIELD":
        return false;
    default:
        return true;
    }
}

function isModifierEnabled(entity, modifier) {
    var name = modifier.name();

    if (name.startsWith("fiskheroes:damage_immunity")) {
        return entity.getData("fiskheroes:shield_blocking");
    }

    var arms = armsActive(entity);
    if (arms) {
        switch (name) {
        case "fiskheroes:shield":
        case "fiskheroes:charged_beam":
        case "fiskheroes:spellcasting":
        case "fiskheroes:telekinesis":
        case "fiskheroes:intangibility":
            return false;
        }
    }

    return true;
}
