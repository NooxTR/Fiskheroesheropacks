extend("fiskheroes:hero_basic");
loadTextures({
    "layer1": "cosmicverse:cosmic_punch_layer1",
    "layer2": "cosmicverse:cosmic_punch_layer2"
});

var utils = implement("fiskheroes:external/utils");
var RED = 0xFF2200;

function init(renderer) {
    parent.init(renderer);
    renderer.setTexture((entity, renderLayer) => {
        return renderLayer == "LEGGINGS" ? "layer2" : "layer1";
    });
}

function initAnimations(renderer) {
    parent.initAnimations(renderer);
    renderer.removeCustomAnimation("basic.PROP_FLIGHT");
    utils.addFlightAnimation(renderer, "cosmicpunch.FLIGHT", "fiskheroes:flight/default_arms_forward.anim.json");
    utils.addHoverAnimation(renderer, "cosmicpunch.HOVER", "fiskheroes:flight/idle/neutral");
}

function initEffects(renderer) {
    renderer.bindProperty("fiskheroes:equipment_wheel").color.set(RED);

    var ff = renderer.bindProperty("fiskheroes:forcefield");
    ff.color.set(RED);
    ff.setShape(36, 18).setOffset(0.0, 10.0, 0.0).setScale(2.4);
    ff.setCondition(entity => {
        var blocking = entity.getData("fiskheroes:shield_blocking");
        if (!blocking) return false;
        ff.opacity = 0.15 + 0.3 * entity.getInterpolatedData("fiskheroes:shield_blocking_timer");
        return true;
    });

    var beamRenderer = renderer.createResource("BEAM_RENDERER", "fiskheroes:charged_beam");
    utils.bindBeam(renderer, "fiskheroes:charged_beam", beamRenderer, "rightArm", RED, [
        { "firstPerson": [0.0, -6.15, 0.0], "offset": [-1.5, 9.0, -0.25], "size": [12.5, 12.5] }
    ]).setParticles(renderer.createResource("PARTICLE_EMITTER", "cosmicverse:impact_cosmic_punch"));
}
