extend("fiskheroes:spider_man_base");
loadTextures({
    "layer1":      "cosmicverse:cosmic_spider_man_layer1",
    "layer2":      "cosmicverse:cosmic_spider_man_layer2",
    "segment":     "cosmicverse:cosmic_arm",
    "claw":        "cosmicverse:cosmic_claw",
    "claw_lights": "cosmicverse:cosmic_claw_lights"
});

var utils = implement("fiskheroes:external/utils");
var PURPLE = 0x8800FF;
var LIGHT_PURPLE = 0xAA44FF;

function init(renderer) {
    parent.init(renderer);
    renderer.setTexture((entity, renderLayer) => {
        return renderLayer == "LEGGINGS" ? "layer2" : "layer1";
    });
}

function initAnimations(renderer) {
    parent.initAnimations(renderer);
    renderer.removeCustomAnimation("basic.PROP_FLIGHT");
    utils.addFlightAnimation(renderer, "cosmicverse.flight", "fiskheroes:flight/default.anim.json");
    utils.addHoverAnimation(renderer, "cosmicverse.hover", "fiskheroes:flight/idle/default");
}

function initEffects(renderer) {
    // Geçişkenlik - yarı saydam efekt
    utils.setOpacityWithData(renderer, 0.3, 1.0, "fiskheroes:intangibility_timer");

    // Mor küre kalkan - sadece aktifken oluşur
    var ff = renderer.bindProperty("fiskheroes:forcefield");
    ff.color.set(PURPLE);
    ff.setShape(36, 18).setOffset(0.0, 10.0, 0.0).setScale(2.4);
    ff.setCondition(entity => {
        var blocking = entity.getData("fiskheroes:shield_blocking");
        if (!blocking) return false;
        ff.opacity = 0.2 + 0.3 * entity.getInterpolatedData("fiskheroes:shield_blocking_timer");
        return true;
    });

    // Büyü çarkı rengi
    renderer.bindProperty("fiskheroes:equipment_wheel").color.set(PURPLE);

    // Büyü efektleri
    var magic = renderer.bindProperty("fiskheroes:spellcasting");
    magic.colorGeneric.set(PURPLE);
    magic.colorAtmosphere.set(PURPLE);
    magic.colorWhip.set(LIGHT_PURPLE);

    // Telekinezi bulutu
    utils.bindCloud(renderer, "fiskheroes:telekinesis", "fiskheroes:telekinesis_monitor");

    // Kozmik mor tentacles
    var segmentModel = utils.createModel(renderer, "fiskheroes:ock_arm", "segment");
    var clawModel    = utils.createModel(renderer, "fiskheroes:ock_claw", "claw", "claw_lights");

    clawModel.bindAnimation("fiskheroes:ock_claw").setData((entity, data) => {
        var t = entity.as("TENTACLE");
        data.load(0, 1 - Math.min(t.getCaster().getInterpolatedData("fiskheroes:tentacle_extend_timer") * 2, 1));
        data.load(1, t.getIndex());
        data.load(2, t.getGrabTimer());
        data.load(3, t.getStrikeTimer());
    });

    var tentacles = renderer.bindProperty("fiskheroes:tentacles").setTentacles([
        { "offset": [2.0, -4.5, -2.0],  "direction": [13.0,  10.0, -10.0] },
        { "offset": [-2.0, -4.5, -2.0], "direction": [-13.0, 10.0, -10.0] },
        { "offset": [2.0, -7.5, -2.0],  "direction": [13.0, -10.0, -10.0] },
        { "offset": [-2.0, -7.5, -2.0], "direction": [-13.0,-10.0, -10.0] }
    ]);
    tentacles.anchor.set("body");
    tentacles.setSegmentModel(segmentModel);
    tentacles.setHeadModel(clawModel);
    tentacles.segmentLength = 1.8;
    tentacles.segments = 16;
    // Mor charged_beam efekti - impact_antimatter partikülleri
    utils.bindBeam(renderer, "fiskheroes:charged_beam", "fiskheroes:energy_projection", "rightArm", PURPLE, [
        { "firstPerson": [3.0, 2.0, -8.0], "offset": [1.5, -3.0, -4.0], "size": [10.0, 10.0] }
    ]).setParticles(renderer.createResource("PARTICLE_EMITTER", "fiskheroes:impact_antimatter"));

}
