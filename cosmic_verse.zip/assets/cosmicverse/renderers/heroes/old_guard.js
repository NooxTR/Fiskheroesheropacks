extend("fiskheroes:hero_basic");
loadTextures({
    "layer1": "cosmicverse:old_guard_layer1",
    "layer2": "cosmicverse:old_guard_layer2"
});

var GRAY   = 0x9A9A9A;
var utils  = implement("fiskheroes:external/utils");

function init(renderer) {
    parent.init(renderer);
    renderer.setTexture((entity, renderLayer) => {
        return renderLayer == "LEGGINGS" ? "layer2" : "layer1";
    });
}

function initEffects(renderer) {
    renderer.bindProperty("fiskheroes:equipment_wheel").color.set(GRAY);

    var ff = renderer.bindProperty("fiskheroes:forcefield");
    ff.color.set(GRAY);
    ff.setShape(36, 18).setOffset(0.0, 10.0, 0.0).setScale(2.4);
    ff.setCondition(entity => {
        var blocking = entity.getData("fiskheroes:shield_blocking");
        if (!blocking) return false;
        ff.opacity = 0.15 + 0.3 * entity.getInterpolatedData("fiskheroes:shield_blocking_timer");
        return true;
    });

    // Power Punch - küçük mor parlama (kalkanla aynı kanıtlanmış forcefield tekniği)
    var pg = renderer.bindProperty("fiskheroes:forcefield");
    pg.color.set(0x9400D3);
    pg.setShape(8, 8).setOffset(-6.0, 6.0, -4.0).setScale(0.5);
    pg.setCondition(entity => {
        var active = entity.getData("fiskheroes:punchmode");
        if (!active) return false;
        pg.opacity = 0.6;
        return true;
    });
}
